#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Servidor de Teste de Velocidade (versao com console de acompanhamento).

Usa APENAS a biblioteca padrao do Python (nao precisa instalar nada extra).
O MESMO arquivo roda no Windows e num servidor Linux (nuvem) sem alterar nada.

Como usar:
  - Rode:  python servidor.py    (ou clique em iniciar.bat)
  - A janela (console) mostra AO VIVO: logins, testes iniciados/encerrados e
    a velocidade atingida.
  - Abra no navegador o endereco que aparecer.
  - Entre como "admin" (a senha aparece no console na primeira vez).
  - Cadastre tecnicos e defina os limites de download/upload de cada um.
  - O tecnico entra com o usuario/senha dele e faz os testes pelo navegador.

Comando extra:
  - python servidor.py --reset-admin   (gera uma nova senha para o admin)
  - python servidor.py --versao        (mostra a versao e sai)
"""

# Marca de versao: o iniciar.bat confere isto para garantir que o arquivo
# corrigido esta na pasta. NAO apague a linha abaixo.
# MARCA-VERSAO-2-0-UPLOAD-CONSTANTE
VERSAO = "2.4"
VERSAO_NOTA = "download com varias conexoes + modo combinado (juntos / alternado)"

import os
import sys
import json
import time
import base64
import hmac
import hashlib
import secrets
import sqlite3
import socket
import threading
import html
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote_plus


# ============================================================
#  Log no console (para acompanhar ao vivo)
# ============================================================

_LOG_LOCK = threading.Lock()


def logar(msg):
    with _LOG_LOCK:
        print("[%s] %s" % (time.strftime("%H:%M:%S"), msg))
        sys.stdout.flush()


# ============================================================
#  Caminhos e configuracao
# ============================================================

def base_dir():
    v = os.environ.get("SERVIDOR_HOME")
    if v:
        return os.path.abspath(v)
    return os.path.dirname(os.path.abspath(sys.argv[0]))


DIRS = {}
CONFIG = {}
DB_LOCK = threading.Lock()


def initialize():
    global DIRS, CONFIG
    b = base_dir()
    DIRS = {
        "base": b,
        "config": os.path.join(b, "config"),
        "banco": os.path.join(b, "banco"),
        "logs": os.path.join(b, "logs"),
    }
    for p in (DIRS["config"], DIRS["banco"], DIRS["logs"]):
        os.makedirs(p, exist_ok=True)

    cfg_path = os.path.join(DIRS["config"], "config.json")
    if os.path.exists(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as f:
            CONFIG = json.load(f)
    else:
        CONFIG = {"host": "0.0.0.0", "port": 8080,
                  "conexoes_upload": 4, "conexoes_download": 4}
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(CONFIG, f, indent=2)

    return init_db()


def _conexoes(chave):
    try:
        n = int(CONFIG.get(chave, 4))
    except (ValueError, TypeError):
        n = 4
    return max(1, min(8, n))


def conexoes_upload_padrao():
    """Quantas conexoes o upload usa por padrao (o tecnico pode mudar na
    hora do teste). Fica em config/config.json, chave "conexoes_upload"."""
    return _conexoes("conexoes_upload")


def conexoes_download_padrao():
    """Mesma ideia para o download (chave "conexoes_download").

    Uma conexao so mede o que UM fluxo unico consegue - e o mais parecido
    com baixar um arquivo. Varias em paralelo enchem melhor o cano quando
    a latencia ate o servidor e alta.
    """
    return _conexoes("conexoes_download")


def db_path():
    return os.path.join(DIRS["banco"], "servidor.db")


def get_db():
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS technicians (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                username          TEXT NOT NULL UNIQUE,
                password_hash     TEXT NOT NULL,
                name              TEXT NOT NULL DEFAULT '',
                status            TEXT NOT NULL DEFAULT 'ativo',
                role              TEXT NOT NULL DEFAULT 'tecnico',
                max_download_mbps INTEGER NOT NULL DEFAULT 0,
                max_upload_mbps   INTEGER NOT NULL DEFAULT 0,
                created_at        TEXT NOT NULL DEFAULT (datetime('now'))
            );
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS test_history (
                id                         INTEGER PRIMARY KEY AUTOINCREMENT,
                technician_id              INTEGER,
                started_at                 TEXT,
                ended_at                   TEXT,
                ip                         TEXT,
                direction                  TEXT,
                requested_mbps             INTEGER,
                achieved_avg_mbps          REAL,
                bytes_total                INTEGER DEFAULT 0,
                duration_seconds           INTEGER DEFAULT 0,
                end_reason                 TEXT
            );
            """
        )
        conn.commit()
        count = conn.execute("SELECT COUNT(*) AS c FROM technicians").fetchone()["c"]
        admin_pass = None
        if count == 0:
            admin_pass = gen_password(12)
            conn.execute(
                "INSERT INTO technicians "
                "(username, password_hash, name, status, role, max_download_mbps, max_upload_mbps) "
                "VALUES (?,?,?,?,?,?,?)",
                ("admin", hash_password(admin_pass), "Administrador", "ativo", "admin", 1000, 1000),
            )
            conn.commit()
        return admin_pass
    finally:
        conn.close()


# ============================================================
#  Senhas (PBKDF2-HMAC-SHA256, tudo da biblioteca padrao)
# ============================================================

def hash_password(plain):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt, 200000)
    return "pbkdf2$200000$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(dk).decode()


def verify_password(plain, stored):
    try:
        parts = stored.split("$")
        if len(parts) != 4 or parts[0] != "pbkdf2":
            return False
        iters = int(parts[1])
        salt = base64.b64decode(parts[2])
        want = base64.b64decode(parts[3])
        dk = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt, iters)
        return hmac.compare_digest(dk, want)
    except Exception:
        return False


def gen_password(n):
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(n))


# ============================================================
#  Sessoes (token guardado na memoria do servidor)
# ============================================================

SESSIONS = {}
SESS_LOCK = threading.Lock()
SESSION_TTL = 8 * 3600


def create_session(tech):
    token = secrets.token_urlsafe(24)
    with SESS_LOCK:
        SESSIONS[token] = {
            "tech_id": tech["id"],
            "username": tech["username"],
            "role": tech["role"],
            "expires": time.time() + SESSION_TTL,
        }
    return token


def get_session(token):
    if not token:
        return None
    with SESS_LOCK:
        s = SESSIONS.get(token)
        if not s:
            return None
        if s["expires"] < time.time():
            SESSIONS.pop(token, None)
            return None
        return s


def destroy_session(token):
    with SESS_LOCK:
        SESSIONS.pop(token, None)


def destroy_sessions_for(tech_id):
    with SESS_LOCK:
        for t in [k for k, v in SESSIONS.items() if v["tech_id"] == tech_id]:
            SESSIONS.pop(t, None)


# ============================================================
#  Protecao simples contra forca bruta
# ============================================================

FAILED = {}
FAIL_LOCK = threading.Lock()


def is_locked(username):
    with FAIL_LOCK:
        _, until = FAILED.get(username, (0, 0))
        return until > time.time()


def record_fail(username):
    with FAIL_LOCK:
        c, _ = FAILED.get(username, (0, 0))
        c += 1
        if c >= 5:
            FAILED[username] = (0, time.time() + 300)
        else:
            FAILED[username] = (c, 0)


def clear_fail(username):
    with FAIL_LOCK:
        FAILED.pop(username, None)


# ============================================================
#  Testes ativos (para monitorar e salvar historico)
# ============================================================

TESTS = {}
TESTS_LOCK = threading.Lock()

# Pedacos de dado ALEATORIO para o download. Bloco zerado pode ser
# comprimido por equipamento no caminho e falsear a medida (o upload ja
# usava aleatorio; o download tinha ficado com zeros). Sao gerados uma
# vez na partida - gerar a cada envio nao acompanharia 1 Gbps.
MOLDE_ALEATORIO = [os.urandom(64 * 1024) for _ in range(16)]


def finalizar_teste(t, motivo="parou"):
    """Registra no console e salva no historico um teste que terminou."""
    dur = max(0.001, time.time() - t["start"])
    mbps_real = t["bytes"] * 8 / 1e6 / dur
    # Teste que nao transferiu nada NAO e um resultado de 0 Mbps: e um
    # teste cancelado antes de comecar. Marcar como "0.0 Mbps" no
    # historico parece falha de link, e num laudo isso engana.
    if t["bytes"] <= 0:
        motivo = "cancelado"
    logar("TESTE %s ENCERRADO: %s - %.1f MB em %.1fs (~%.1f Mbps) [%s]"
          % (t["direction"].upper(), t["username"], t["bytes"] / 1e6, dur, mbps_real, motivo))
    try:
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute(
                    "INSERT INTO test_history "
                    "(technician_id, started_at, ended_at, ip, direction, requested_mbps, "
                    " achieved_avg_mbps, bytes_total, duration_seconds, end_reason) "
                    "VALUES (?, datetime('now','localtime'), datetime('now','localtime'), ?, ?, ?, ?, ?, ?, ?)",
                    (t["tech_id"], t["ip"], t["direction"], int(t["mbps"]),
                     round(mbps_real, 2), int(t["bytes"]), int(dur), motivo),
                )
                conn.commit()
            finally:
                conn.close()
    except Exception as e:
        logar("erro ao salvar historico: %s" % e)


def reaper_loop():
    """Encerra testes 'abandonados' (o tecnico fechou o navegador sem parar)."""
    while True:
        time.sleep(15)
        agora = time.time()
        mortos = []
        with TESTS_LOCK:
            for tid, t in list(TESTS.items()):
                if agora - t.get("last", t["start"]) > 45:
                    mortos.append(t)
                    TESTS.pop(tid, None)
        for t in mortos:
            finalizar_teste(t, motivo="perda")


# ============================================================
#  Acesso a tecnicos no banco
# ============================================================

def get_tech_by_username(username):
    conn = get_db()
    try:
        return conn.execute("SELECT * FROM technicians WHERE username=?", (username,)).fetchone()
    finally:
        conn.close()


def get_tech_by_id(tid):
    conn = get_db()
    try:
        return conn.execute("SELECT * FROM technicians WHERE id=?", (tid,)).fetchone()
    finally:
        conn.close()


def list_techs():
    conn = get_db()
    try:
        return conn.execute("SELECT * FROM technicians ORDER BY role DESC, username").fetchall()
    finally:
        conn.close()


# ============================================================
#  HTML
# ============================================================

CSS = """<style>
 body{font-family:system-ui,Segoe UI,Arial,sans-serif;max-width:960px;margin:0 auto;padding:16px;color:#111;background:#f6f7f9}
 header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;border-bottom:1px solid #ddd;padding-bottom:8px;margin-bottom:16px}
 h1{font-size:20px;margin:0} h2{font-size:17px}
 nav a{margin-left:10px;color:#0a58ca;text-decoration:none}
 table{width:100%;border-collapse:collapse;background:#fff}
 th,td{border:1px solid #ddd;padding:6px 8px;text-align:left;font-size:14px;vertical-align:top}
 th{background:#eef1f5}
 input,select,button{padding:6px 8px;font-size:14px;border:1px solid #bbb;border-radius:4px}
 button{cursor:pointer;background:#0a58ca;color:#fff;border:none}
 button.sec{background:#6c757d} button.danger{background:#c0392b}
 .card{background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px;margin-bottom:16px}
 .big{font-size:44px;font-weight:bold;margin:8px 0;color:#0a58ca}
 .msg-ok{background:#d1e7dd;padding:8px;border-radius:4px;margin-bottom:12px}
 .msg-err{background:#f8d7da;padding:8px;border-radius:4px;margin-bottom:12px}
 label{display:inline-block;min-width:150px} .row{margin:8px 0}
 .muted{color:#666;font-size:13px}
 form.inline{display:inline}
</style>"""


def build_nav(sess):
    if not sess:
        return ""
    nav = "<a href='/test'>Testar velocidade</a>"
    if sess["role"] == "admin":
        nav += " <a href='/admin'>Tecnicos</a>"
        nav += " <a href='/admin/historico'>Historico</a>"
    nav += " <a href='/logout'>Sair (" + html.escape(sess["username"]) + ")</a>"
    return nav


def render_page(title, body, sess=None):
    return (
        "<!doctype html><html lang='pt-br'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width, initial-scale=1'>"
        "<title>" + html.escape(title) + "</title>" + CSS + "</head><body>"
        "<header><h1>" + html.escape(title) + "</h1><nav>" + build_nav(sess) + "</nav></header>"
        + body + "</body></html>"
    )


def msg_block(q):
    out = ""
    if q.get("ok"):
        out += "<div class='msg-ok'>" + html.escape(q["ok"][0]) + "</div>"
    if q.get("erro"):
        out += "<div class='msg-err'>" + html.escape(q["erro"][0]) + "</div>"
    return out


TEST_JS = """
<script>
async function post(url,obj){
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj||{})});
  try{return await r.json();}catch(e){return {};}
}

let dlId=null, dlCtrl=null, dlRun=false, dlTimer=null, dlErro=null;
let ulId=null, ulRun=false, ulTimer=null, ulErro=null;
let cbRun=false;

/* Quantas conexoes o upload usa ao mesmo tempo: o TECNICO escolhe no
   campo "Conexoes ao mesmo tempo". O padrao inicial vem de
   config/config.json (chave "conexoes_upload").
   Uma so conexao fica limitada a (tamanho do pedaco / tempo de ida e
   volta), e qualquer variacao da latencia aparece como oscilacao na
   medida. Varias em paralelo cobrem o buraco uma da outra.
   Acima de 6 o proprio navegador enfileira, entao nao adianta muito. */
const UL_PEDACO   = 256*1024;
const JANELA_MS   = 3000;   /* janela da taxa instantanea */
const AQUEC_MS    = 2000;   /* descarta o aquecimento do TCP na media */

function quantasConexoes(campo){
  const el=document.getElementById(campo);
  let n=el?parseInt(el.value,10):4;
  if(!isFinite(n)||n<1) n=1;
  if(n>8) n=8;
  if(el) el.value=n;          /* mostra o valor realmente usado */
  return n;
}
function ulQuantasConexoes(){ return quantasConexoes('ulConn'); }
function dlQuantasConexoes(){ return quantasConexoes('dlConn'); }

function dormir(ms){ return new Promise(r=>setTimeout(r,ms)); }

/* Dados aleatorios: dados zerados podem ser comprimidos no caminho
   e falsear a medida. crypto.getRandomValues aceita 64 KB por vez. */
function pedacoAleatorio(n){
  const a=new Uint8Array(n);
  for(let o=0;o<n;o+=65536) crypto.getRandomValues(a.subarray(o,Math.min(o+65536,n)));
  return a;
}

/* Medidor com janela deslizante: mostra a taxa AGORA, nao a media
   desde o inicio (que nunca se recupera de um engasgo). */
function criarMedidor(elemId){
  return {el:document.getElementById(elemId), amostras:[], bytes:0, t0:performance.now(),
    add(n){ this.bytes+=n; },
    mostrar(){
      const agora=performance.now();
      this.amostras.push([agora,this.bytes]);
      while(this.amostras.length>2 && agora-this.amostras[0][0]>JANELA_MS) this.amostras.shift();
      const a=this.amostras[0], z=this.amostras[this.amostras.length-1];
      const dt=(z[0]-a[0])/1000;
      if(dt<0.4) return;
      const inst=(z[1]-a[1])*8/1e6/dt;
      const decorrido=(agora-this.t0)/1000;
      let txt=inst.toFixed(1)+' Mbps';
      if(decorrido>(AQUEC_MS/1000)+1){
        const media=(this.bytes-(this.aqBytes||0))*8/1e6/(decorrido-AQUEC_MS/1000);
        txt+=" <span style='font-size:.5em;opacity:.7'>(media "+media.toFixed(1)+")</span>";
      } else if(this.aqBytes===undefined && decorrido>AQUEC_MS/1000){
        this.aqBytes=this.bytes;
      }
      if(this.rotulo) txt+=" <span style='font-size:.4em;opacity:.6'>"+this.rotulo+"</span>";
      this.el.innerHTML=txt;
    }};
}

/* Um "trabalhador" de download = uma conexao lendo o fluxo do servidor.
   O servidor divide a velocidade pedida entre as conexoes (parametro n),
   entao 4 conexoes nao entregam 4x o que foi pedido. */
async function dlTrabalhador(tid, nconx, medidor){
  try{
    const resp=await fetch('/download?test_id='+tid+'&n='+nconx,
                           {signal:dlCtrl.signal,cache:'no-store'});
    if(!resp.ok){
      dlErro=(resp.status===401||resp.status===403)
        ? 'sessao expirou - entre de novo (erro '+resp.status+')'
        : 'o servidor recusou o download (erro '+resp.status+')';
      return;
    }
    const reader=resp.body.getReader();
    while(dlRun){
      const r=await reader.read(); if(r.done) break;
      medidor.add(r.value.length);
    }
  }catch(e){
    /* abortar pelo botao Parar cai aqui: nao e erro */
    if(dlRun && !dlErro) dlErro='conexao com o servidor falhou ('+(e && e.message ? e.message : e)+')';
  }
}

async function startDownload(){
  if(dlRun) return;                 /* ja esta rodando */
  dlRun=true; dlErro=null;          /* trava ANTES do await: duplo clique
                                       nao cria dois testes */
  const el=document.getElementById('dlResult');
  if(el) el.textContent='iniciando...';
  try{
    const mbps=parseFloat(document.getElementById('dlMbps').value)||1;
    const s=await post('/test/start',{direction:'download',mbps:mbps});
    if(s.error){ dlRun=false; mostrarAviso('dlResult',s.error); return; }
    if(!s.test_id){ dlRun=false; mostrarAviso('dlResult','o servidor nao devolveu o teste'); return; }
    if(!dlRun){                     /* clicou em Parar durante o start */
      await post('/test/stop',{test_id:s.test_id}); return;
    }
    dlId=s.test_id; dlCtrl=new AbortController();
    const conexoes=dlQuantasConexoes();
    const m=criarMedidor('dlResult');
    m.rotulo=conexoes+(conexoes>1?' conexoes':' conexao');
    dlTimer=setInterval(()=>m.mostrar(),500);
    const equipe=[];
    for(let i=0;i<conexoes;i++) equipe.push(dlTrabalhador(dlId,conexoes,m));
    await Promise.all(equipe);
    if(dlErro) mostrarAviso('dlResult',dlErro);
  }catch(e){
    mostrarAviso('dlResult','falhou: '+(e && e.message ? e.message : e));
  }finally{
    dlRun=false;
    if(dlTimer){ clearInterval(dlTimer); dlTimer=null; }
  }
}
async function stopDownload(){
  /* Avisar o servidor ANTES de abortar. Se abortar primeiro, o servidor
     ve a conexao morrer e registra "perda" - que num laudo de campo se
     confunde com perda de pacote / queda de link. */
  dlRun=false;
  if(dlTimer){ clearInterval(dlTimer); dlTimer=null; }
  if(dlId){ await post('/test/stop',{test_id:dlId}); dlId=null; }
  if(dlCtrl){ dlCtrl.abort(); dlCtrl=null; }
}

/* Um "trabalhador" = uma conexao keep-alive mandando pedaco atras de pedaco. */
async function ulTrabalhador(tid, pedaco, bpsCota, medidor){
  let prazo=performance.now(), falhas=0;
  while(ulRun){
    try{
      const r=await fetch('/upload?test_id='+tid,{method:'POST',body:pedaco,cache:'no-store'});
      if(!r.ok){
        /* Antes isso parava tudo em silencio e o teste ficava 0.0 MB
           sem explicacao. Agora diz o porque na tela. */
        ulErro = (r.status===401||r.status===403)
          ? 'sessao expirou - entre de novo (erro '+r.status+')'
          : 'o servidor recusou o envio (erro '+r.status+')';
        ulRun=false; break;
      }
      await r.arrayBuffer();   /* drena a resposta: libera a conexao para reuso */
      falhas=0;
    }catch(e){
      if(!ulRun) break;
      falhas++;
      if(falhas>=20){          /* nao adianta insistir para sempre calado */
        ulErro='conexao com o servidor falhou ('+(e && e.message ? e.message : e)+')';
        ulRun=false; break;
      }
      await dormir(150);       /* engasgo pontual: tenta de novo, nao mata o teste */
      continue;
    }
    if(!ulRun) break;
    medidor.add(pedaco.length);
    if(bpsCota>0){
      prazo+=(pedaco.length/bpsCota)*1000;
      const agora=performance.now();
      if(prazo>agora) await dormir(prazo-agora);
      else if(agora-prazo>1000) prazo=agora;  /* atrasou demais: perdoa a divida
                                                 em vez de disparar uma rajada */
    }
  }
}

function mostrarAviso(elemId, txt){
  const el=document.getElementById(elemId);
  if(el) el.innerHTML="<span style='font-size:.42em;color:#b00'>"+txt+"</span>";
}

async function startUpload(){
  if(ulRun) return;                 /* ja esta rodando */
  ulRun=true; ulErro=null;          /* trava ANTES do await: evita duplo clique
                                       criar dois testes ao mesmo tempo */
  const el=document.getElementById('ulResult');
  if(el) el.textContent='iniciando...';
  let s;
  try{
    const mbps=parseFloat(document.getElementById('ulMbps').value)||1;
    s=await post('/test/start',{direction:'upload',mbps:mbps});
    if(s.error){ ulRun=false; mostrarAviso('ulResult',s.error); return; }
    if(!s.test_id){ ulRun=false; mostrarAviso('ulResult','o servidor nao devolveu o teste'); return; }
    if(!ulRun){                     /* clicou em Parar durante o start */
      await post('/test/stop',{test_id:s.test_id}); return;
    }
    ulId=s.test_id;
    const conexoes=ulQuantasConexoes();
    const pedaco=pedacoAleatorio(UL_PEDACO);
    const cota=(s.mbps*1e6/8)/conexoes;
    const m=criarMedidor('ulResult');
    m.rotulo=conexoes+(conexoes>1?' conexoes':' conexao');
    ulTimer=setInterval(()=>m.mostrar(),500);
    const equipe=[];
    for(let i=0;i<conexoes;i++) equipe.push(ulTrabalhador(ulId,pedaco,cota,m));
    await Promise.all(equipe);
    if(ulErro) mostrarAviso('ulResult',ulErro);
  }catch(e){
    /* Sem isto o erro sumia no console do navegador e o teste ficava
       zerado sem explicacao nenhuma na tela. */
    mostrarAviso('ulResult','falhou: '+(e && e.message ? e.message : e));
  }finally{
    ulRun=false;
    if(ulTimer){ clearInterval(ulTimer); ulTimer=null; }
  }
}
async function stopUpload(){
  ulRun=false;
  if(ulTimer){ clearInterval(ulTimer); ulTimer=null; }
  if(ulId){ await post('/test/stop',{test_id:ulId}); ulId=null; }
}

/* ---------------- teste COMBINADO ----------------
   juntos    = download e upload ao mesmo tempo. Mostra o link com
               trafego nos dois sentidos (onde bufferbloat aparece).
   alternado = um bloco de download, um bloco de upload, sem parar.
               Cada sentido e medido limpo, um nao rouba banda do outro. */
function cbEstado(txt){
  const el=document.getElementById('cbEstado');
  if(el) el.textContent=txt;
}
function cbTempoBloco(){
  const el=document.getElementById('cbBloco');
  let n=el?parseInt(el.value,10):60;
  if(!isFinite(n)||n<5) n=5;
  if(n>600) n=600;
  if(el) el.value=n;
  return n*1000;
}
/* dorme, mas acorda na hora se alguem clicar em Parar */
async function dormirOuParar(ms){
  const fim=performance.now()+ms;
  while(cbRun && performance.now()<fim) await dormir(200);
}

async function startCombo(){
  if(cbRun) return;
  cbRun=true;
  const modo=document.getElementById('cbModo').value;
  try{
    if(modo==='juntos'){
      cbEstado('rodando os dois ao mesmo tempo');
      await Promise.all([startDownload(), startUpload()]);
      return;
    }
    const bloco=cbTempoBloco();
    while(cbRun){
      cbEstado('volta de DOWNLOAD');
      const d=startDownload();
      await dormirOuParar(bloco);
      await stopDownload();
      await d;
      if(!cbRun) break;
      cbEstado('volta de UPLOAD');
      const u=startUpload();
      await dormirOuParar(bloco);
      await stopUpload();
      await u;
    }
  }finally{
    cbRun=false;
    cbEstado('parado');
  }
}
async function stopCombo(){
  cbRun=false;
  cbEstado('parando...');
  await stopDownload();
  await stopUpload();
  cbEstado('parado');
}
</script>
"""


# ============================================================
#  Servidor HTTP
# ============================================================

class Handler(BaseHTTPRequestHandler):
    server_version = "ServidorTesteVelocidade"

    # HTTP/1.1 = keep-alive: a MESMA conexao TCP e reaproveitada.
    # Sem isso, cada pedaco do upload abre uma conexao nova, o TCP
    # recomeca do zero (slow start) e o Windows esgota as portas.
    protocol_version = "HTTP/1.1"
    disable_nagle_algorithm = True   # TCP_NODELAY: sem atraso artificial
    timeout = 300                    # derruba conexao ociosa presa

    def log_message(self, fmt, *args):
        # silencioso: usamos logar() so para eventos importantes
        return

    def handle_one_request(self):
        """Conexao que cai NAO e erro de programa.

        Com keep-alive a conexao fica aberta entre uma requisicao e outra.
        Quando o navegador a fecha, quando o tecnico clica em Parar (o
        fetch e abortado) ou quando o wifi oscila, o Python levanta
        ConnectionResetError bem no meio da leitura da proxima requisicao.
        Sem este tratamento o socketserver despeja um traceback inteiro no
        console a cada teste encerrado, e a janela de acompanhamento fica
        inutilizavel. Aqui a conexao e apenas encerrada em silencio.
        """
        try:
            BaseHTTPRequestHandler.handle_one_request(self)
        except (ConnectionError, TimeoutError, socket.timeout):
            self.close_connection = True

    # ---- helpers ----
    def cookies(self):
        raw = self.headers.get("Cookie", "")
        out = {}
        for part in raw.split(";"):
            if "=" in part:
                k, v = part.strip().split("=", 1)
                out[k] = v
        return out

    def session(self):
        return get_session(self.cookies().get("sid"))

    def client_ip(self):
        return self.client_address[0] if self.client_address else "?"

    def send_html(self, body, status=200, extra=None):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        # Sem isto, depois de atualizar o servidor o navegador pode servir
        # a pagina ANTIGA do cache, com o JavaScript velho junto.
        self.send_header("Cache-Control", "no-store, must-revalidate")
        for k, v in (extra or []):
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, obj, status=200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location, extra=None):
        self.send_response(303)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        for k, v in (extra or []):
            self.send_header(k, v)
        self.end_headers()

    def read_body(self):
        self._corpo_lido = True
        length = int(self.headers.get("Content-Length", 0) or 0)
        return self.rfile.read(length) if length > 0 else b""

    def drenar_corpo(self):
        """Com keep-alive o corpo PRECISA ser lido ate o fim. Se um handler
        sai antes (ex.: 401 sem ler), o resto vira lixo na proxima
        requisicao da mesma conexao e o upload embaralha."""
        if getattr(self, "_corpo_lido", False):
            return
        self._corpo_lido = True
        try:
            restante = int(self.headers.get("Content-Length", 0) or 0)
        except (ValueError, TypeError):
            return
        while restante > 0:
            try:
                pedaco = self.rfile.read(min(65536, restante))
            except OSError:
                return
            if not pedaco:
                return
            restante -= len(pedaco)

    def form(self):
        return {k: v[0] for k, v in parse_qs(self.read_body().decode("utf-8", "replace")).items()}

    def json_body(self):
        raw = self.read_body()
        try:
            return json.loads(raw.decode("utf-8", "replace")) if raw else {}
        except Exception:
            return {}

    def require_admin(self):
        s = self.session()
        if not s or s["role"] != "admin":
            self.redirect("/login")
            return None
        return s

    # ---- roteamento ----
    def do_GET(self):
        u = urlparse(self.path)
        path, q = u.path, parse_qs(u.query)
        if path == "/":
            return self.page_root()
        if path == "/login":
            return self.page_login(q)
        if path == "/logout":
            return self.action_logout()
        if path == "/admin":
            return self.page_admin(q)
        if path == "/admin/historico":
            return self.page_historico(q)
        if path == "/test":
            return self.page_test()
        if path == "/download":
            return self.data_download(q)
        return self.send_html(render_page("Nao encontrado", "<p>404</p>"), 404)

    def do_POST(self):
        self._corpo_lido = False
        try:
            self.rotear_post()
        finally:
            self.drenar_corpo()

    def rotear_post(self):
        path = urlparse(self.path).path
        if path == "/login":
            return self.action_login()
        if path == "/test/start":
            return self.action_test_start()
        if path == "/test/stop":
            return self.action_test_stop()
        if path == "/upload":
            return self.data_upload()
        if path == "/admin/create":
            return self.action_create()
        if path == "/admin/update":
            return self.action_update()
        if path == "/admin/setstatus":
            return self.action_setstatus()
        if path == "/admin/delete":
            return self.action_delete()
        if path == "/admin/password":
            return self.action_password()
        return self.send_html(render_page("Nao encontrado", "<p>404</p>"), 404)

    # ---- paginas ----
    def page_root(self):
        s = self.session()
        if not s:
            return self.redirect("/login")
        return self.redirect("/admin" if s["role"] == "admin" else "/test")

    def page_login(self, q):
        if self.session():
            return self.redirect("/")
        body = (
            "<div class='card' style='max-width:380px;margin:40px auto'>" + msg_block(q) +
            "<h2>Entrar</h2>"
            "<form method='post' action='/login'>"
            "<div class='row'><label>Usuario</label><input name='username' autofocus></div>"
            "<div class='row'><label>Senha</label><input name='password' type='password'></div>"
            "<div class='row'><button type='submit'>Entrar</button></div>"
            "</form></div>"
        )
        return self.send_html(render_page("Servidor de Teste de Velocidade", body))

    def action_login(self):
        f = self.form()
        username = (f.get("username") or "").strip()
        password = f.get("password") or ""
        if is_locked(username):
            return self.redirect("/login?erro=" + quote_plus("Muitas tentativas. Aguarde 5 minutos."))
        tech = get_tech_by_username(username)
        if not tech or tech["status"] != "ativo" or not verify_password(password, tech["password_hash"]):
            record_fail(username)
            logar("LOGIN FALHOU: '%s' (IP %s)" % (username, self.client_ip()))
            return self.redirect("/login?erro=" + quote_plus("Usuario ou senha invalidos (ou bloqueado)."))
        clear_fail(username)
        token = create_session(tech)
        logar("LOGIN: %s (IP %s)" % (username, self.client_ip()))
        cookie = "sid=" + token + "; HttpOnly; Path=/; SameSite=Lax"
        return self.redirect("/", extra=[("Set-Cookie", cookie)])

    def action_logout(self):
        s = self.session()
        if s:
            logar("LOGOUT: %s" % s["username"])
        destroy_session(self.cookies().get("sid"))
        return self.redirect("/login", extra=[("Set-Cookie", "sid=; Path=/; Max-Age=0")])

    def page_admin(self, q):
        s = self.require_admin()
        if not s:
            return
        rows = list_techs()
        t = "<table><tr><th>Usuario</th><th>Nome</th><th>Tipo</th><th>Status</th>" \
            "<th>Download (Mbps)</th><th>Upload (Mbps)</th><th>Acoes</th></tr>"
        for r in rows:
            is_admin = r["role"] == "admin"
            actions = (
                "<form class='inline' method='post' action='/admin/update'>"
                "<input type='hidden' name='id' value='" + str(r["id"]) + "'>"
                "nome <input name='name' value='" + html.escape(r["name"]) + "' size='10'> "
                "dl <input name='max_download_mbps' value='" + str(r["max_download_mbps"]) + "' size='4'> "
                "ul <input name='max_upload_mbps' value='" + str(r["max_upload_mbps"]) + "' size='4'> "
                "<button class='sec' type='submit'>Salvar</button></form> "
                "<form class='inline' method='post' action='/admin/password'>"
                "<input type='hidden' name='id' value='" + str(r["id"]) + "'>"
                "nova senha <input name='password' size='10'> "
                "<button class='sec' type='submit'>Trocar</button></form> "
            )
            if not is_admin:
                novo = "bloqueado" if r["status"] == "ativo" else "ativo"
                rotulo = "Bloquear" if r["status"] == "ativo" else "Desbloquear"
                actions += (
                    "<form class='inline' method='post' action='/admin/setstatus'>"
                    "<input type='hidden' name='id' value='" + str(r["id"]) + "'>"
                    "<input type='hidden' name='status' value='" + novo + "'>"
                    "<button class='sec' type='submit'>" + rotulo + "</button></form> "
                    "<form class='inline' method='post' action='/admin/delete' "
                    "onsubmit='return confirm(\"Excluir este tecnico?\")'>"
                    "<input type='hidden' name='id' value='" + str(r["id"]) + "'>"
                    "<button class='danger' type='submit'>Excluir</button></form>"
                )
            t += (
                "<tr><td>" + html.escape(r["username"]) + "</td><td>" + html.escape(r["name"]) + "</td>"
                "<td>" + html.escape(r["role"]) + "</td><td>" + html.escape(r["status"]) + "</td>"
                "<td>" + str(r["max_download_mbps"]) + "</td><td>" + str(r["max_upload_mbps"]) + "</td>"
                "<td>" + actions + "</td></tr>"
            )
        t += "</table>"
        create = (
            "<div class='card'><h2>Criar novo tecnico</h2>"
            "<form method='post' action='/admin/create'>"
            "<div class='row'><label>Usuario</label><input name='username'></div>"
            "<div class='row'><label>Nome</label><input name='name'></div>"
            "<div class='row'><label>Senha</label><input name='password'></div>"
            "<div class='row'><label>Download max (Mbps)</label><input name='max_download_mbps' value='100'></div>"
            "<div class='row'><label>Upload max (Mbps)</label><input name='max_upload_mbps' value='50'></div>"
            "<div class='row'><button type='submit'>Criar tecnico</button></div>"
            "</form></div>"
        )
        body = msg_block(q) + "<div class='card'><h2>Tecnicos</h2>" + t + "</div>" + create
        return self.send_html(render_page("Painel - Tecnicos", body, s))

    def page_historico(self, q):
        s = self.require_admin()
        if not s:
            return
        conn = get_db()
        try:
            rows = conn.execute(
                "SELECT h.*, t.username AS uname FROM test_history h "
                "LEFT JOIN technicians t ON t.id = h.technician_id "
                "ORDER BY h.id DESC LIMIT 50"
            ).fetchall()
        finally:
            conn.close()
        t = "<table><tr><th>Quando</th><th>Tecnico</th><th>Direcao</th><th>Pedido</th>" \
            "<th>Atingido</th><th>Dados</th><th>Duracao</th><th>Fim</th></tr>"
        for r in rows:
            uname = r["uname"] if r["uname"] else ("id " + str(r["technician_id"]))
            mb = (r["bytes_total"] or 0) / 1e6
            t += (
                "<tr><td>" + html.escape(str(r["ended_at"] or "")) + "</td>"
                "<td>" + html.escape(str(uname)) + "</td>"
                "<td>" + html.escape(str(r["direction"] or "")) + "</td>"
                "<td>" + str(r["requested_mbps"] or 0) + " Mbps</td>"
                "<td>" + (("%.1f Mbps" % r["achieved_avg_mbps"])
                          if (r["bytes_total"] or 0) > 0 else
                          "<span class='muted'>--</span>") + "</td>"
                "<td>" + ("%.1f" % mb) + " MB</td>"
                "<td>" + str(r["duration_seconds"] or 0) + " s</td>"
                "<td>" + html.escape(str(r["end_reason"] or "")) + "</td></tr>"
            )
        t += "</table>"
        if not rows:
            t = "<p class='muted'>Nenhum teste registrado ainda.</p>"
        return self.send_html(render_page("Painel - Historico", "<div class='card'><h2>Ultimos 50 testes</h2>" + t + "</div>", s))

    def page_test(self):
        s = self.session()
        if not s:
            return self.redirect("/login")
        tech = get_tech_by_id(s["tech_id"])
        max_dl = tech["max_download_mbps"] if tech else 0
        max_ul = tech["max_upload_mbps"] if tech else 0

        def section(titulo, maxv, input_id, btn_start, btn_stop, result_id, extra=""):
            if maxv <= 0:
                return ("<div class='card'><h2>" + titulo + "</h2>"
                        "<p class='muted'>Limite nao definido pelo administrador.</p></div>")
            return (
                "<div class='card'><h2>" + titulo + "</h2>"
                "<div class='row'><label>Velocidade (Mbps)</label>"
                "<input id='" + input_id + "' type='number' min='1' max='" + str(maxv) + "' value='" + str(maxv) + "'> "
                "<span class='muted'>maximo permitido: " + str(maxv) + "</span></div>"
                + extra +
                "<div class='row'><button onclick='" + btn_start + "()'>Iniciar</button> "
                "<button class='sec' onclick='" + btn_stop + "()'>Parar</button></div>"
                "<div class='big' id='" + result_id + "'>--</div></div>"
            )

        def campo_conexoes(input_id, padrao):
            return (
                "<div class='row'><label>Conexoes ao mesmo tempo</label>"
                "<input id='" + input_id + "' type='number' min='1' max='8' value='"
                + str(padrao) + "'> "
                "<span class='muted'>1 = fluxo unico &nbsp;|&nbsp; 4 = padrao &nbsp;|&nbsp; "
                "acima de 6 o navegador enfileira</span></div>"
            )

        # Quadro do teste combinado: so aparece se o login tem os DOIS lados.
        combinado = ""
        if max_dl > 0 and max_ul > 0:
            combinado = (
                "<div class='card'><h2>Teste COMBINADO (download + upload)</h2>"
                "<div class='row'><label>Como rodar</label>"
                "<select id='cbModo'>"
                "<option value='alternado'>Alternado - um de cada vez</option>"
                "<option value='juntos'>Ao mesmo tempo - os dois juntos</option>"
                "</select></div>"
                "<div class='row' id='cbLinhaBloco'><label>Tempo de cada volta</label>"
                "<input id='cbBloco' type='number' min='5' max='600' value='60'> "
                "<span class='muted'>segundos de download, depois o mesmo de upload "
                "(so vale no modo alternado)</span></div>"
                "<div class='row'><button onclick='startCombo()'>Iniciar</button> "
                "<button class='sec' onclick='stopCombo()'>Parar</button> "
                "<span class='muted' id='cbEstado'>parado</span></div>"
                "<p class='muted'>Usa a velocidade e as conexoes que voce escolheu nos "
                "quadros acima. Os numeros aparecem em cada quadro.<br>"
                "<b>Ao mesmo tempo</b> mostra como o link se comporta com trafego nos dois "
                "sentidos (e onde aparece bufferbloat). <b>Alternado</b> mede cada sentido "
                "limpo, sem um atrapalhar o outro.</p></div>"
            )

        body = (
            "<p>Ola, <b>" + html.escape(s["username"]) + "</b>. "
            "Seu limite: download ate <b>" + str(max_dl) + " Mbps</b>, "
            "upload ate <b>" + str(max_ul) + " Mbps</b>.</p>"
            + section("Teste de DOWNLOAD", max_dl, "dlMbps", "startDownload", "stopDownload",
                      "dlResult", campo_conexoes("dlConn", conexoes_download_padrao()))
            + section("Teste de UPLOAD", max_ul, "ulMbps", "startUpload", "stopUpload",
                      "ulResult", campo_conexoes("ulConn", conexoes_upload_padrao()))
            + combinado
            + "<p class='muted'>O teste continua ate voce clicar em Parar.</p>" + TEST_JS
        )
        return self.send_html(render_page("Teste de velocidade", body, s))

    # ---- acoes de admin ----
    def action_create(self):
        if not self.require_admin():
            return
        f = self.form()
        username = (f.get("username") or "").strip()
        name = (f.get("name") or "").strip()
        password = f.get("password") or ""
        dl, ul = _to_int(f.get("max_download_mbps")), _to_int(f.get("max_upload_mbps"))
        if not username or not password:
            return self.redirect("/admin?erro=" + quote_plus("Preencha usuario e senha."))
        err = None
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute(
                    "INSERT INTO technicians "
                    "(username,password_hash,name,status,role,max_download_mbps,max_upload_mbps) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (username, hash_password(password), name, "ativo", "tecnico", dl, ul),
                )
                conn.commit()
            except sqlite3.IntegrityError:
                err = "Esse usuario ja existe."
            finally:
                conn.close()
        if err:
            return self.redirect("/admin?erro=" + quote_plus(err))
        logar("ADMIN: tecnico criado: %s (dl %d / ul %d)" % (username, dl, ul))
        return self.redirect("/admin?ok=" + quote_plus("Tecnico criado."))

    def action_update(self):
        if not self.require_admin():
            return
        f = self.form()
        tid = _to_int(f.get("id"))
        name = (f.get("name") or "").strip()
        dl, ul = _to_int(f.get("max_download_mbps")), _to_int(f.get("max_upload_mbps"))
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute("UPDATE technicians SET name=?, max_download_mbps=?, max_upload_mbps=? WHERE id=?",
                             (name, dl, ul, tid))
                conn.commit()
            finally:
                conn.close()
        return self.redirect("/admin?ok=" + quote_plus("Dados atualizados."))

    def action_setstatus(self):
        if not self.require_admin():
            return
        f = self.form()
        tid = _to_int(f.get("id"))
        status = f.get("status") or "ativo"
        if status not in ("ativo", "bloqueado"):
            status = "ativo"
        tech = get_tech_by_id(tid)
        if tech and tech["role"] == "admin":
            return self.redirect("/admin?erro=" + quote_plus("Nao e possivel bloquear um administrador."))
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute("UPDATE technicians SET status=? WHERE id=?", (status, tid))
                conn.commit()
            finally:
                conn.close()
        if status == "bloqueado":
            destroy_sessions_for(tid)
        logar("ADMIN: %s -> %s" % (tech["username"] if tech else tid, status))
        return self.redirect("/admin?ok=" + quote_plus("Status alterado."))

    def action_delete(self):
        if not self.require_admin():
            return
        f = self.form()
        tid = _to_int(f.get("id"))
        tech = get_tech_by_id(tid)
        if tech and tech["role"] == "admin":
            return self.redirect("/admin?erro=" + quote_plus("Nao e possivel excluir um administrador."))
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute("DELETE FROM technicians WHERE id=?", (tid,))
                conn.commit()
            finally:
                conn.close()
        destroy_sessions_for(tid)
        logar("ADMIN: tecnico excluido: %s" % (tech["username"] if tech else tid))
        return self.redirect("/admin?ok=" + quote_plus("Tecnico excluido."))

    def action_password(self):
        if not self.require_admin():
            return
        f = self.form()
        tid = _to_int(f.get("id"))
        password = f.get("password") or ""
        if len(password) < 3:
            return self.redirect("/admin?erro=" + quote_plus("Senha muito curta."))
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute("UPDATE technicians SET password_hash=? WHERE id=?",
                             (hash_password(password), tid))
                conn.commit()
            finally:
                conn.close()
        return self.redirect("/admin?ok=" + quote_plus("Senha alterada."))

    # ---- inicio/fim de teste ----
    def action_test_start(self):
        s = self.session()
        if not s:
            return self.send_json({"error": "nao autenticado"}, 401)
        b = self.json_body()
        direction = b.get("direction")
        try:
            mbps = float(b.get("mbps", 0))
        except (ValueError, TypeError):
            mbps = 0
        tech = get_tech_by_id(s["tech_id"])
        if direction == "download":
            maxv = tech["max_download_mbps"] if tech else 0
        elif direction == "upload":
            maxv = tech["max_upload_mbps"] if tech else 0
        else:
            return self.send_json({"error": "direcao invalida"}, 400)
        if maxv <= 0:
            return self.send_json({"error": "limite nao definido para " + direction}, 403)
        if mbps > maxv:
            mbps = float(maxv)
        if mbps < 1:
            mbps = 1.0
        test_id = secrets.token_urlsafe(12)
        with TESTS_LOCK:
            TESTS[test_id] = {"tech_id": s["tech_id"], "username": s["username"],
                              "direction": direction, "mbps": mbps, "start": time.time(),
                              "last": time.time(), "bytes": 0, "ip": self.client_ip()}
        logar("TESTE %s INICIADO: %s pediu %.0f Mbps (IP %s)"
              % (direction.upper(), s["username"], mbps, self.client_ip()))
        return self.send_json({"test_id": test_id, "mbps": mbps})

    def action_test_stop(self):
        s = self.session()
        if not s:
            return self.send_json({"error": "nao autenticado"}, 401)
        test_id = self.json_body().get("test_id")
        with TESTS_LOCK:
            t = TESTS.pop(test_id, None)
        if t and t["tech_id"] == s["tech_id"]:
            finalizar_teste(t, motivo="parou")
        return self.send_json({"ok": True})

    # ---- plano de dados (o teste em si) ----
    def data_download(self, q):
        s = self.session()
        if not s:
            return self.send_json({"error": "nao autenticado"}, 401)
        test_id = q.get("test_id", [None])[0]
        with TESTS_LOCK:
            t = TESTS.get(test_id)
        if not t or t["tech_id"] != s["tech_id"] or t["direction"] != "download":
            return self.send_json({"error": "teste invalido"}, 400)

        # Quantas conexoes o cliente abriu para ESTE MESMO teste (&n=).
        # A velocidade pedida e DIVIDIDA entre elas: 4 conexoes de um
        # teste de 1000 Mbps saem a 250 Mbps cada. Sem isso o servidor
        # mandaria 4000 Mbps e a medida viraria ficcao.
        try:
            nconx = int(q.get("n", ["1"])[0])
        except (ValueError, TypeError):
            nconx = 1
        nconx = max(1, min(8, nconx))

        mbps = t["mbps"]
        with TESTS_LOCK:
            if test_id in TESTS:
                TESTS[test_id]["conexoes"] = TESTS[test_id].get("conexoes", 0) + 1

        # Stream sem fim definido: sob HTTP/1.1 tem que avisar que fecha,
        # senao o navegador fica esperando um Content-Length que nao vem.
        self.close_connection = True
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()

        target_bps = mbps * 1_000_000 / 8.0 / nconx
        sent = 0
        contado = 0          # quanto ja foi somado no total do teste
        pool = MOLDE_ALEATORIO
        npool = len(pool)
        i = 0
        start = time.perf_counter()
        try:
            while True:
                with TESTS_LOCK:
                    if test_id not in TESTS:
                        break
                chunk = pool[i % npool]
                i += 1
                self.wfile.write(chunk)
                sent += len(chunk)
                now = time.time()
                # SOMA (+=) em vez de atribuir: com varias conexoes no mesmo
                # teste, atribuir fazia uma apagar a contagem da outra.
                with TESTS_LOCK:
                    t2 = TESTS.get(test_id)
                    if t2 is not None:
                        t2["bytes"] += sent - contado
                        t2["last"] = now
                        contado = sent
                elapsed = time.perf_counter() - start
                if elapsed > 3600:
                    break
                delay = (sent / target_bps) - elapsed
                if delay > 0:
                    time.sleep(delay)
        except OSError:
            pass

        # So a ULTIMA conexao a sair encerra o teste. Antes, a primeira a
        # fechar ja marcava "perda" e as irmas continuavam sem dono.
        leftover = None
        with TESTS_LOCK:
            t2 = TESTS.get(test_id)
            if t2 is not None:
                t2["conexoes"] = max(0, t2.get("conexoes", 1) - 1)
                if t2["conexoes"] <= 0:
                    leftover = TESTS.pop(test_id, None)
        if leftover:
            # se o cliente caiu sem chamar /test/stop, finaliza aqui
            finalizar_teste(leftover, motivo="perda")

    def data_upload(self):
        s = self.session()
        if not s:
            # drenar_corpo() no do_POST cuida do corpo que sobrou
            return self.send_json({"error": "nao autenticado"}, 401)
        test_id = parse_qs(urlparse(self.path).query).get("test_id", [None])[0]

        self._corpo_lido = True
        try:
            length = int(self.headers.get("Content-Length", 0) or 0)
        except (ValueError, TypeError):
            length = 0
        remaining, received, buf = length, 0, 64 * 1024
        parcial, ultimo_flush = 0, time.time()
        try:
            while remaining > 0:
                data = self.rfile.read(min(buf, remaining))
                if not data:
                    break
                received += len(data)
                parcial += len(data)
                remaining -= len(data)
                # contabiliza durante a recepcao: mantem o teste "vivo"
                # para o reaper mesmo num envio grande e lento
                agora = time.time()
                if agora - ultimo_flush >= 1.0:
                    with TESTS_LOCK:
                        t = TESTS.get(test_id)
                        if t and t["tech_id"] == s["tech_id"] and t["direction"] == "upload":
                            t["bytes"] += parcial
                            t["last"] = agora
                    parcial, ultimo_flush = 0, agora
        except OSError:
            pass
        if parcial:
            with TESTS_LOCK:
                t = TESTS.get(test_id)
                if t and t["tech_id"] == s["tech_id"] and t["direction"] == "upload":
                    t["bytes"] += parcial
                    t["last"] = time.time()
        return self.send_json({"bytes": received})


def _to_int(v):
    try:
        return int(str(v).strip())
    except (ValueError, TypeError, AttributeError):
        return 0


# ============================================================
#  Deteccao de rede
# ============================================================

def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def is_global_ipv6(ip):
    ip = ip.split("%")[0].lower()
    if ip in ("::1", "::", ""):
        return False
    if ip.startswith("fe80"):
        return False
    if ip.startswith("fc") or ip.startswith("fd"):
        return False
    first = ip.split(":")[0]
    try:
        val = int(first, 16)
    except ValueError:
        return False
    return 0x2000 <= val <= 0x3fff


def public_ipv6():
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2001:4860:4860::8888", 80))
        ip = s.getsockname()[0]
        s.close()
        if is_global_ipv6(ip):
            return ip.split("%")[0]
    except Exception:
        pass
    return None


def public_ipv4():
    servicos = ("https://api.ipify.org", "https://ipv4.icanhazip.com", "https://checkip.amazonaws.com")
    for url in servicos:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "servidor"})
            with urllib.request.urlopen(req, timeout=4) as r:
                ip = r.read().decode("utf-8", "replace").strip()
            partes = ip.split(".")
            if len(partes) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in partes):
                return ip
        except Exception:
            continue
    return None


class ServidorSilencioso(ThreadingHTTPServer):
    """Segunda barreira contra o traceback de conexao caida.

    Alem do handler, o proprio socketserver pode pegar a queda antes
    (durante o setup da conexao, por exemplo). Aqui a queda e ignorada,
    mas erro DE VERDADE continua aparecendo - em uma linha so, no mesmo
    formato dos outros avisos, em vez de um traceback gigante.
    """
    daemon_threads = True

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionError, TimeoutError, socket.timeout)):
            return
        try:
            ip = client_address[0] if client_address else "?"
        except (IndexError, TypeError):
            ip = "?"
        logar("ERRO ao atender %s: %s: %s" % (ip, type(exc).__name__, exc))


class DualStackServer(ServidorSilencioso):
    address_family = socket.AF_INET6
    daemon_threads = True

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except (AttributeError, OSError):
            pass
        super().server_bind()


def build_server(port):
    try:
        return DualStackServer(("::", port), Handler)
    except OSError:
        return ServidorSilencioso(("0.0.0.0", port), Handler)


# ============================================================
#  Inicializacao (console)
# ============================================================

def main():
    admin_pass = initialize()
    port = int(CONFIG.get("port", 8080))
    httpd = build_server(port)
    threading.Thread(target=reaper_loop, daemon=True).start()

    ip4_lan = local_ip()
    ip4_pub = public_ipv4()
    ip6 = public_ipv6()

    print("=" * 62)
    print(" SERVIDOR DE TESTE DE VELOCIDADE   -   versao %s" % VERSAO)
    print(" %s" % VERSAO_NOTA)
    print("=" * 62)
    print(" ACESSO LOCAL (neste PC e na sua rede):")
    print("   neste computador:  http://localhost:%d" % port)
    if ip4_lan:
        print("   mesma rede (wifi): http://%s:%d" % (ip4_lan, port))
    print("-" * 62)
    print(" INTERNET (tecnico acessando de qualquer lugar):")
    tem_net = False
    if ip4_pub:
        tem_net = True
        print("   >> IPv4 publico:  http://%s:%d" % (ip4_pub, port))
        if ip4_lan and ip4_lan == ip4_pub:
            print("      (este PC tem IP publico direto - tende a funcionar ja)")
        else:
            print("      ATENCAO: atras de roteador -> pode precisar liberar a")
            print("      porta %d no roteador (redirecionamento de porta)." % port)
    if ip6:
        tem_net = True
        print("   -- IPv6 (alternativa): http://[%s]:%d" % (ip6, port))
    if not tem_net:
        print("   Sem endereco de internet detectado (sem internet ou CG-NAT).")
        print("   Dica: rodar este MESMO arquivo num servidor na nuvem (Linux)")
        print("   resolve o CG-NAT e o firewall de uma vez.")
    print("-" * 62)
    if admin_pass:
        print(" PRIMEIRO ACESSO - conta administrador criada:")
        print("   usuario: admin")
        print("   senha..: %s" % admin_pass)
        print("   (guarde essa senha; para trocar use o painel)")
        print("-" * 62)
    print(" ACOMPANHE ABAIXO ao vivo (logins e testes):")
    print(" Para encerrar: feche esta janela ou use parar.bat")
    print("=" * 62)
    sys.stdout.flush()

    logar("Servidor no ar na porta %d" % port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrando...")
    finally:
        httpd.shutdown()


def reset_admin():
    initialize()
    newpass = gen_password(12)
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute("SELECT id FROM technicians WHERE role='admin' ORDER BY id LIMIT 1").fetchone()
            if row:
                conn.execute("UPDATE technicians SET password_hash=?, status='ativo' WHERE id=?",
                             (hash_password(newpass), row["id"]))
            else:
                conn.execute(
                    "INSERT INTO technicians "
                    "(username,password_hash,name,status,role,max_download_mbps,max_upload_mbps) "
                    "VALUES (?,?,?,?,?,?,?)",
                    ("admin", hash_password(newpass), "Administrador", "ativo", "admin", 1000, 1000),
                )
            conn.commit()
        finally:
            conn.close()
    print("Nova senha do admin: %s" % newpass)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--versao":
        print(VERSAO)
    elif len(sys.argv) > 1 and sys.argv[1] == "--reset-admin":
        reset_admin()
    else:
        main()
