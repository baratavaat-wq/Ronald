@echo off
cd /d "%~dp0"
title Servidor de Teste de Velocidade

REM ============================================================
REM  INICIAR O SERVIDOR
REM  Confere se o servidor.py CORRIGIDO (versao 2.0 - upload
REM  constante) esta na pasta antes de ligar.
REM ============================================================

REM --- O arquivo do servidor esta aqui? ---
if not exist "%~dp0servidor.py" (
  echo ============================================================
  echo  ARQUIVO "servidor.py" NAO ENCONTRADO NESTA PASTA.
  echo  Deixe todos os arquivos do pacote juntos na mesma pasta.
  echo ============================================================
  echo.
  pause
  exit /b 1
)

REM --- Procura o Python instalado ---
set PY=
where python >nul 2>&1 && set PY=python
if not defined PY ( where py >nul 2>&1 && set PY=py )

if not defined PY (
  echo ============================================================
  echo  O PYTHON NAO FOI ENCONTRADO NESTE COMPUTADOR.
  echo.
  echo  1^) Baixe em:  https://www.python.org/downloads/
  echo  2^) Ao instalar, MARQUE a caixa "Add Python to PATH".
  echo  3^) Depois abra este iniciar.bat de novo.
  echo ============================================================
  pause
  exit /b 1
)

REM --- Confere se a correcao do upload esta no arquivo ---
findstr /C:"MARCA-VERSAO-2-0-UPLOAD-CONSTANTE" "%~dp0servidor.py" >nul 2>&1
if errorlevel 1 (
  echo ============================================================
  echo  ATENCAO: este servidor.py e a versao ANTIGA.
  echo.
  echo  Nela o upload CORTA depois de alguns segundos, porque cada
  echo  pedaco enviado abria uma conexao nova e o Windows ficava
  echo  sem portas disponiveis.
  echo.
  echo  Copie o servidor.py da versao 2.0 para esta pasta,
  echo  substituindo o antigo, e abra o iniciar.bat de novo.
  echo ============================================================
  echo.
  pause
  exit /b 1
)

set VER=
for /f "delims=" %%v in ('%PY% "%~dp0servidor.py" --versao 2^>nul') do set VER=%%v
if not defined VER set VER=2.4

echo ============================================================
echo  Servidor de velocidade  ^(versao %VER%^)
echo    - conexao reaproveitada ^(keep-alive^)
echo    - conexoes ao mesmo tempo no DOWNLOAD e no UPLOAD
echo    - teste combinado: alternado ou os dois ao mesmo tempo
echo    - velocidade constante, sem cortes
echo ============================================================
echo.
echo Iniciando o servidor... (para PARAR, feche esta janela)
echo.
%PY% "%~dp0servidor.py"
echo.
echo O servidor foi encerrado.
pause
