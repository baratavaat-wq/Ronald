@echo off
echo Encerrando o servidor de teste de velocidade...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='py.exe'\" | Where-Object { $_.CommandLine -like '*servidor.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" 2>nul
echo.
echo Pronto. (Voce tambem pode simplesmente fechar a janela preta do servidor.)
pause
