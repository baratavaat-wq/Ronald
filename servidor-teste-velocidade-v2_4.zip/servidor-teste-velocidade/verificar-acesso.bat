@echo off
setlocal
REM ============================================================
REM  VERIFICAR ACESSO - NAO PRECISA DE ADMINISTRADOR
REM  Confere se o servidor esta no ar, se o firewall esta
REM  liberado e se existe algum bloqueio atrapalhando.
REM  Pode rodar quantas vezes quiser, com dois cliques.
REM ============================================================

echo ============================================================
echo  VERIFICACAO DO SERVIDOR DE TESTE DE VELOCIDADE
echo ============================================================
echo.

set PROBLEMA=0

REM --- 1) O servidor esta rodando (porta 8080 escutando)? ---
echo [1/4] Servidor no ar?
netstat -ano | findstr /C:":8080 " | findstr /I "LISTENING" >nul 2>&1
if errorlevel 1 (
  echo    NAO. Ninguem esta escutando na porta 8080.
  echo    ^>^> Abra o iniciar.bat primeiro e rode esta verificacao de novo.
  set PROBLEMA=1
) else (
  echo    SIM. Porta 8080 escutando.
)
echo.

REM --- 2) A regra de liberacao do firewall existe? ---
echo [2/4] Regra do firewall liberada?
netsh advfirewall firewall show rule name="Servidor Teste Velocidade" >nul 2>&1
if errorlevel 1 (
  echo    NAO. A regra "Servidor Teste Velocidade" nao existe.
  echo    ^>^> Peca a alguem com ADMIN para rodar UMA VEZ o arquivo:
  echo       "liberar-firewall-COMPLETO (ADMIN).bat"
  echo       (botao direito - Executar como administrador)
  set PROBLEMA=1
) else (
  echo    SIM. Regra "Servidor Teste Velocidade" encontrada.
)
echo.

REM --- 3) Existe bloqueio automatico do Windows contra o Python? ---
echo [3/4] Bloqueio escondido do Windows contra o Python?
set "TMPBLQ=%TEMP%\bloqueios_python_srv.txt"
powershell -NoProfile -Command "Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue | Where-Object { $_.Program -like '*python*' } | Get-NetFirewallRule | Where-Object { $_.Action -eq 'Block' -and $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' } | Select-Object -ExpandProperty DisplayName" > "%TMPBLQ%" 2>nul

set TAM=0
for %%A in ("%TMPBLQ%") do set TAM=%%~zA
if %TAM% GTR 2 (
  echo    SIM, TEM BLOQUEIO! O Windows criou regra bloqueando o Python
  echo    ^(isso acontece quando o popup de permissao e clicado sem admin^).
  echo    Regras de bloqueio encontradas:
  type "%TMPBLQ%"
  echo    ^>^> A versao nova do "liberar-firewall-COMPLETO (ADMIN).bat"
  echo       remove esses bloqueios. Peca ao ADMIN para rodar ela.
  set PROBLEMA=1
) else (
  echo    NAO. Nenhum bloqueio contra o Python. Otimo.
)
del "%TMPBLQ%" >nul 2>&1
echo.

REM --- 4) Endereco para testar de outro aparelho ---
echo [4/4] Endereco para teste:
set IPLAN=
for /f "delims=" %%i in ('powershell -NoProfile -Command "(Get-NetIPConfiguration ^| Where-Object { $_.IPv4DefaultGateway -ne $null } ^| Select-Object -First 1).IPv4Address.IPAddress" 2^>nul') do set IPLAN=%%i
if defined IPLAN (
  echo    Na MESMA rede ^(wifi/cabo^):  http://%IPLAN%:8080
) else (
  echo    Nao consegui detectar o IP da rede. Veja na janela preta do servidor.
)
echo.

echo ============================================================
if %PROBLEMA% EQU 0 (
  echo  TUDO CERTO POR AQUI!
  echo.
  echo  TESTE AGORA, nesta ordem:
  echo   1. Celular no WIFI da mesma rede: abra o endereco acima.
  echo   2. Celular no 4G/5G ^(wifi desligado^): abra o endereco de
  echo      "IPv4 publico" que aparece na janela preta do servidor.
  echo.
  echo  Se o passo 1 funciona e o passo 2 nao: o firewall esta OK,
  echo  falta o REDIRECIONAMENTO DA PORTA 8080 no roteador
  echo  ^(ou a conexao esta em CG-NAT - dai so com servidor na nuvem^).
) else (
  echo  ACHEI PENDENCIA ^(veja os itens marcados com ^>^> acima^).
  echo  Resolva e rode esta verificacao de novo.
)
echo ============================================================
echo.
pause
