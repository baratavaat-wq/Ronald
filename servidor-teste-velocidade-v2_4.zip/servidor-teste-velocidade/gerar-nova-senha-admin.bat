@echo off
cd /d "%~dp0"

set PY=
where python >nul 2>&1 && set PY=python
if not defined PY ( where py >nul 2>&1 && set PY=py )
if not defined PY (
  echo Python nao encontrado. Instale em https://www.python.org/downloads/
  pause
  exit /b 1
)

echo Gerando uma nova senha para o usuario "admin"...
echo.
%PY% "%~dp0servidor.py" --reset-admin
echo.
pause
