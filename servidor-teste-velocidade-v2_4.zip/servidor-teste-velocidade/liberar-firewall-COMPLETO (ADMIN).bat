@echo off
REM ============================================================
REM  LIBERAR O SERVIDOR NO FIREWALL - COMPLETO (v2)
REM  Todas as redes (PUBLICA e privada), WIFI ou CABO,
REM  entrada e saida. Corrige o caso de ter liberado so a privada,
REM  remove bloqueios criados sem querer e TAMBEM remove os
REM  bloqueios automaticos que o Windows cria quando o popup de
REM  permissao do Python e respondido sem admin.
REM
REM  >>> Clique com o BOTAO DIREITO neste arquivo e escolha
REM      "Executar como administrador" <<<
REM  >>> So precisa rodar UMA VEZ. Depois disso o servidor
REM      funciona todo dia SEM precisar de admin. <<<
REM ============================================================

REM --- Confere se esta rodando como administrador ---
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo ============================================================
  echo  PRECISA SER EXECUTADO COMO ADMINISTRADOR.
  echo  Feche esta janela, clique com o BOTAO DIREITO no arquivo
  echo  e escolha "Executar como administrador".
  echo ============================================================
  echo.
  pause
  exit /b 1
)

echo Procurando o Python...
set PYEXE=
for /f "delims=" %%i in ('python -c "import sys;print(sys.executable)" 2^>nul') do set PYEXE=%%i
if not defined PYEXE for /f "delims=" %%i in ('py -c "import sys;print(sys.executable)" 2^>nul') do set PYEXE=%%i

echo Limpando regras antigas...
netsh advfirewall firewall delete rule name="Servidor Teste Velocidade" >nul 2>&1
netsh advfirewall firewall delete rule name="Servidor Teste Velocidade OUT" >nul 2>&1
netsh advfirewall firewall delete rule name="Servidor Teste Velocidade (Python IN)" >nul 2>&1
netsh advfirewall firewall delete rule name="Servidor Teste Velocidade (Python OUT)" >nul 2>&1
if defined PYEXE (
  netsh advfirewall firewall delete rule name=all dir=in  program="%PYEXE%" >nul 2>&1
  netsh advfirewall firewall delete rule name=all dir=out program="%PYEXE%" >nul 2>&1
)

echo Removendo bloqueios automaticos do Windows contra QUALQUER Python...
echo (sao criados pelo popup de permissao respondido sem admin)
powershell -NoProfile -Command "Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue | Where-Object { $_.Program -like '*python*' } | Get-NetFirewallRule | Where-Object { $_.Action -eq 'Block' } | Remove-NetFirewallRule -ErrorAction SilentlyContinue" >nul 2>&1

echo Liberando a porta 8080 em todas as redes...
netsh advfirewall firewall add rule name="Servidor Teste Velocidade" dir=in action=allow protocol=TCP localport=8080 profile=any >nul
netsh advfirewall firewall add rule name="Servidor Teste Velocidade OUT" dir=out action=allow protocol=TCP localport=8080 profile=any >nul

if defined PYEXE (
  echo Liberando o programa Python em todas as redes...
  netsh advfirewall firewall add rule name="Servidor Teste Velocidade (Python IN)" dir=in action=allow program="%PYEXE%" enable=yes profile=any >nul
  netsh advfirewall firewall add rule name="Servidor Teste Velocidade (Python OUT)" dir=out action=allow program="%PYEXE%" enable=yes profile=any >nul
  echo   Python liberado: %PYEXE%
) else (
  echo   Observacao: nao localizei o caminho do Python, mas a porta 8080
  echo   foi liberada em todas as redes, o que ja resolve o acesso.
)

echo.
echo ============================================================
echo  PRONTO! Liberado em TODAS as redes (publica e privada),
echo  no WIFI ou no CABO, entrada e saida, e os bloqueios
echo  automaticos do popup foram removidos.
echo.
echo  Este arquivo NAO precisa ser rodado de novo. A partir de
echo  agora o iniciar.bat funciona sem admin.
echo.
echo  Se o popup de permissao do Python aparecer de novo, pode
echo  fechar/cancelar sem medo: a liberacao ja esta gravada.
echo.
echo  Para conferir tudo sem admin: rode o verificar-acesso.bat
echo.
echo  Teste pela internet: pegue um CELULAR no 4G/5G (desligue o
echo  wifi) e abra o endereco do IPv4 publico que aparece na
echo  janela do servidor.
echo ============================================================
echo.
pause
